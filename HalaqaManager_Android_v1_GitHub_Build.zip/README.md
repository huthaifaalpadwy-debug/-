# إدارة الحلقة – Android v1

مشروع Android مستقل لبرنامج إدارة الحلقة.

## الموجود حاليًا
- إضافة الطلاب وحفظهم محليًا.
- حاضر / غائب / مستأذن.
- اليوم الاستثنائي (لا يُحسب غياب).
- واجهة عربية RTL.
- إعداد GitHub Actions لبناء APK سحابيًا من الهاتف دون Android Studio.

## بناء APK من الهاتف
راجع ملف `README_PHONE.md` واتبع الخطوات. لا تحتاج إلى تثبيت Android Studio أو Flutter.

## البناء المحلي
إذا توفر Gradle/JDK 17 يمكن تشغيل:
`gradle assembleDebug`

الناتج:
`app/build/outputs/apk/debug/app-debug.apk`
