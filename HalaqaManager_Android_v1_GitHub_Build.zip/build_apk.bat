@echo off
echo Building Halaqa Manager APK...
if not exist gradlew.bat (
  echo Gradle wrapper is not included in this starter package.
  echo Install Gradle or open the project in Android Studio/compatible IDE.
  pause
  exit /b 1
)
call gradlew.bat assembleDebug
if %ERRORLEVEL% EQU 0 (
  echo APK created under app\build\outputs\apk\debug\
)
pause
