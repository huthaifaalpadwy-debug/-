package com.hsa.halaqa

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("halaqa", MODE_PRIVATE) }
    private val students = mutableListOf<String>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        load()
        build()
    }

    private fun build() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(245,247,250))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val title = TextView(this).apply {
            text = "إدارة الحلقة"
            textSize = 30f; setTextColor(Color.rgb(17,24,39))
            setPadding(0,10,0,6)
        }
        page.addView(title)
        val date = TextView(this).apply {
            text = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar")).format(Date())
            textSize = 16f; setTextColor(Color.DKGRAY)
            setPadding(0,0,0,18)
        }
        page.addView(date)

        val add = Button(this).apply { text = "＋ إضافة طالب"; setOnClickListener { addStudent() } }
        page.addView(add)

        val exceptional = CheckBox(this).apply {
            text = "اليوم استثنائي (لا يُحسب غياب)"
            setPadding(0,12,0,12)
        }
        page.addView(exceptional)

        val header = TextView(this).apply {
            text = "الطلاب"
            textSize = 22f; setPadding(0,20,0,10)
        }
        page.addView(header)

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        page.addView(list)

        val reports = Button(this).apply {
            text = "📊 التقارير"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("التقارير")
                    .setMessage("سيتم إضافة التقارير الشهرية وPDF وExcel في النسخة التالية.")
                    .setPositiveButton("حسنًا", null).show()
            }
        }
        page.addView(reports)
        scroll.addView(page)
        setContentView(scroll)
        refresh()
    }

    private fun addStudent() {
        val input = EditText(this).apply {
            hint = "اسم الطالب"
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        AlertDialog.Builder(this).setTitle("إضافة طالب").setView(input)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) { students.add(name); save(); refresh() }
            }.show()
    }

    private fun refresh() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        students.forEachIndexed { i, name ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(12,12,12,12)
                setBackgroundColor(Color.WHITE)
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            val n = TextView(this).apply { text = "${i+1}. $name"; textSize = 18f; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            row.addView(n)
            val present = Button(this).apply { text = "حاضر"; setOnClickListener { mark(name, "حاضر") } }
            val absent = Button(this).apply { text = "غائب"; setOnClickListener { mark(name, "غائب") } }
            val excused = Button(this).apply { text = "مستأذن"; setOnClickListener { mark(name, "مستأذن") } }
            row.addView(excused); row.addView(absent); row.addView(present)
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0,0,0,8) })
        }
    }

    private fun mark(name:String, status:String) {
        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + "_" + name
        prefs.edit().putString(key, status).apply()
        Toast.makeText(this, "$name: $status", Toast.LENGTH_SHORT).show()
    }

    private fun save() { prefs.edit().putString("students", students.joinToString("\n")).apply() }
    private fun load() {
        val s = prefs.getString("students", "") ?: ""
        if (s.isNotBlank()) students.addAll(s.split("\n").filter { it.isNotBlank() })
    }
}
